import React from "react";
import northpic from './Image/north.jpg';
import southpic from './Image/south.jpg';

const HemishphereDisplay = ({latitude}) => {
    console.log(latitude)
    const hemisphere = latitude > 0 ? 'Northeren hemisphere' : 'Southeren hemisphere';
    const picture = latitude > 0 ? northpic : southpic;
    return(
        <div>
            <img src={picture} alt=""></img>
            {hemisphere}
            </div>
    )
}
export default HemishphereDisplay;